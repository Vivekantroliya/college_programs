# write prg arithmetic Operation

first = float(input("Enter first Number : "))
Second = float(input("Enter Second Number : "))


print("Addition of Two number : ",first+Second)
print("Subtraction of Two number : ",first-Second)
print("Multiplication of Two number : ",first*Second)
print("Division of Two number : ",first/Second)

# OUTPUT
# Enter first Number : 10 
# Enter Second Number : 20
# Addition of Two number :  30.0
# Subtraction of Two number :  -10.0
# Multiplication of Two number :  200.0
# Division of Two number :  0.5
