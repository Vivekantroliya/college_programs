
arr = [4,9,7]

for i in arr:
    print("*"*i)
    
    
# ****
# *********
# *******