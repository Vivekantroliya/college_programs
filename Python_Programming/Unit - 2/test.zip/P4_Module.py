# 4.Create a module with 4 functions of your choice.
# Import and use thefunctions using module in different ways.

def sum(a,b):
    return a+b

def subtract(a,b):
    return a-b

def multiply(a,b):
    return a*b

def divide(a,b):
    return a/b